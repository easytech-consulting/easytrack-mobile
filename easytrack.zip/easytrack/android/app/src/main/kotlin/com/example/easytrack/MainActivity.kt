package com.example.easytrack

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
